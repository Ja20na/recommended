<?php

$db = mysqli_connect("localhost","root", "", "recommended") ;
      if($db){
        print("تم الاتصال بقاعده البيانات");
        
      } else{
        print("لم يتم الاتصال بقاعده البيانات ");
      }


mysqli_set_charset($db,"utf8");

if (isset($_POST['btn'])){
  $name=$_POST['name'];
		$Uid=$_POST['Uid'];
$date=$_POST['date'];
$phone=$_POST['phone'];
$phone1=$_POST['phone1'];
$country=$_POST['country'];
$gender=$_POST['gender'];

$username=$_POST['Uname'];
$pass=$_POST['Upassword'];
$pass2=$_POST['password'];



if($pass==$pass2){
  $pass=md5($pass);
  
  $sql="INSERT INTO patient 
  VALUES ('NULL','$name', '$Uid', '$gender', '$date','$country', '$phone', '$phone1', '$username', '$pass' )";
   $result = $db->query($sql);
}}
header("location:step3.php");
?>