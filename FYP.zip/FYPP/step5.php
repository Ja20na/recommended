<!DOCTYPE html>
<html >

<head>
  <meta charset="UTF-8">
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

 
</head>


  
<body >
   <img src="img\logo.png" alt="Mountain View" class="img" width=200 height=150  >
    
    <div class="text" ><h3 style="color:#003651;">Recommended System in HealthCare </h3>
    <h4>to advise Chronic Deseases Batient</h4></div>
  
  <br><br>
    
    <form action="treatment.php" method="POST">
      <br><br>
      <h2> <span class="number">5</span>الادوية </h2>
        
      <fieldset>
        
        <img src="img\treatment.jpg" alt="body" class="imgbody" width=150 height=150  >
        <br><br><br>
          <label for="trname">اسم الدواء</label>
          <input type="text" id="trname" name="trname" placeholder="مثال : انسولين">
          
          <label for="trtype" > نوع الدواء </label> 
                     <select name="trtype" id="trtype">
                     
                        <option value="injection">ابرة</option>
                        <option value="ointment">مرهم</option>
                        <option value="spray">بخاخ</option>
                        <option value="tablet">حبوب</option>
                        <option value="drink">شراب او مضاد حيوي</option>
                        
                     </select>
          
          <label for="drugs">الجرعه</label>
          <input type="text" id="drugs" name="drugs" placeholder=" 20mm">
          
          <label for="times">عدد مرات الاستخدام في اليوم</label>
          <input type="number" id="times" name="times" >
          
          
             <a > تنبيه :لاضافه اكثر من دواء اضغط على اضافه  </a>
             
             <br><br>
          <input type="submit" value="التالي" name="subnext">
       
        
      <input type="submit" value="إضافه" name="sub" >
        
      </fieldset>
  
    
    </form>
      <br><br>
</body>
 

<footer class="container-fluid text-center">
  <p></p>
</footer>





</html>
