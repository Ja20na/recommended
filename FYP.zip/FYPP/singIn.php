<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Center the loader */
#loader {
  position: absolute;
  left: 50%;
  top: 70%;
  z-index: 1;
  width: 40px;
  height: 40px;
  margin: -75px 0 0 -75px;
  border: 10px solid #f3f3f3;
  border-radius: 50%;
  border-top: 10px solid #3498db;
  width: 30px;
  height: 30px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}
footer {
    text-align: center;
      padding: 3px;
	  
	  background-color: #003651;
      color : white ;
       position: fixed;
   left: 0;
   bottom: 0;
width: 100%;
height: 30px;
}
     
      
    
    header{ padding: 3px;
    background-color: #003651;
      color : white ;
       position: fixed;
   left: 0;
   bottom: 0;
width: 100%;
    height: 30px;
    }
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

/* Add animation to "page content" */
.animate-bottom {
 
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

button {
    background: #1A779B;
    border: none;
    padding: 5px 15px;
    color: #fff;
    border-radius: 5px;
    margin-left: 47%;
    font-size: 16px;
	    display: block;
}

#myDiv {
    margin: 60px 0 0 -90px;
    text-align: center;
    
    
  
}
.img{
    position: relative;
     left: 40%;
  top: 50%;
   margin-top: 40px;
   align-items: center;
     -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
 }
 .text{
    text-align: center;
     margin: 0 0 0 -90px;
color:#1A779B;
-webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}
input[type=text] {
    
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 12px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 5px 40px 5px 40px;
}
input[type=password] {
    
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 12px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 5px 40px 5px 40px;
}

</style>
</head>

<body onload="myFunction();" >
 <header>
  <p></p>
 </header>
    <a href="test.html"><img src="img\logo.png" alt="Mountain View" class="img" width=200 height=150  ></a>
    
    <div class="text" ><h3 style="color:#003651;">Recommended System in HealthCare </h3>
    <h4>to advise Chronic Disease Batient</h4></div>
    
                <div id="loader" ></div>

        <div style="display:none;" id="myDiv" class="animate-bottom">
            
                    <form action="code.php" method="POST">
                    <input type="text" name="Uname" placeholder="اسم المستخدم ">
                    <br><br>
                   
                    <input type="password" name="Upass" placeholder="كلمة المرور">
                    <br><br>
                    <button type="submit" name="submit">تسجيل دخول</button>
                    </form>
                    <br><br>
                    <a href="">نسيت كلمه المرور</a><br><br>
                     <a>ليس لديك حساب !  <a href="singUp.php">تسجيل جديد</a></a>
                    
        </div>

<script>
var myVar;

function myFunction() {
    myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>

<footer class="container-fluid text-center">
  <p></p>
</footer>

</body>
</html>
