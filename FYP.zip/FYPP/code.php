//login 

<?php

session_start();

$db = mysqli_connect("localhost","root", "", "recommended") ;
      if($db){
        print("تم الاتصال بقاعده البيانات");
        
      } else{
        print("لم يتم الاتصال بقاعده البيانات ");
      }

mysqli_set_charset($db,"utf8");


if(isset($_POST["submit"]) && isset($_POST["Uname"]) && isset($_POST["Upass"])){
  //Connection to database with mysqli
	
	//get from input 
	$username = $_POST["Uname"];
	$password = md5($_POST["Upass"]);

	
	if(strlen($username) <= 3){
		$error = "Username Must Be More Than 3 Letters";	
	}else{
		if(strlen($password) <= 6){ 
			$error = "Password Must Be More Than 6 Letters"; 
		}else{
			$sql = "SELECT * FROM user WHERE Uname='$username' and Upass='$password'";
			
			$result = mysqli_query($db,$sql);

			
			//var_dump($row);die();
					# code...
					if (mysqli_num_rows($result) == 1 ){
						while ($row=mysqli_fetch_array($result)){
						$_SESSION["user"]=$username;
				$_SESSION["pass"] = $password;
				//$_SESSION['uid'] = $row['Uid'];
				$_SESSION['logged'] = true;
				header('location:profile.php');
						}
					}
				else{
					$error=" ";
					
				}

			
		}
	}
} 
?>


	
	