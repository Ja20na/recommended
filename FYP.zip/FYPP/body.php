<?php

$db = mysqli_connect("localhost","root", "", "recommended") ;
      if($db){
        print("تم الاتصال بقاعده البيانات");
        
      } else{
        print("لم يتم الاتصال بقاعده البيانات ");
      }


mysqli_set_charset($db,"utf8");

if (isset($_POST['btn'])){
  $length=$_POST['length'];
		$wight=$_POST['wight'];
    $diabetes =$_POST['diabetes'];
    $pressure =$_POST['pressure'];
    $cholestrol =$_POST['cholestrol'];
    $date = date("Y/m/d") ;

//convert from cm to m

$res_length = $length/ 100;
//echo $res_length ;
$mass= $wight / ( $res_length * $res_length ) ;
//echo $mass ;
$calories = $wight * 24 * 1.4 ;
//echo $calories ;
$water = ($wight *30 ) / 1000 ;
//echo $water ;


  $sql="INSERT INTO bodydata 
  VALUES ('NULL','$wight','$length', '$mass', '$water', '$calories', '$diabetes', '$pressure', '$cholestrol',CURRENT_DATE())";
   $result = $db->query($sql);
}

header("location:step5.php");
?>