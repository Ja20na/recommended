
<!DOCTYPE html>
<html >

<head>
  <meta charset="UTF-8">
  <title>RS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

  
</head>


  
<body class="animate-bottom">
   <a href="test.html"><img src="img\logo.png" alt="Mountain View" class="img" width=200 height=150   ></a>
    
    <div class="text" ><h3 style="color:#003651;">Recommended System in HealthCare </h3>
    <h4>to advise Chronic Deseases Batient</h4></div>
  
  <br><br>
    
      <form action="register.php" method="POST">
      <br><br>
        <h2> <span class="number">1</span>معلومات المريض</h2>
        
        <fieldset>
          
       
          <label for="name">الاسم</label>
          <input type="text" id="name" name="name">
          
          <label for="Uid">السجل المدني</label>
          <input type="number" id="Uid" name="Uid">
          
           <label for="date">  تاريخ الميلاد</label>
          <input type="date" id="date" name="date" >
          
          
          <label for="phone">رقم جوال</label>
          <input type="tel" id="phone" name="phone" >
          
          <label for="phone1">  رقم جوال اخر</label>
          <input type="tel" id="phone1" name="phone1" >
          
         
          
          <label for="country" > المنطقة </label> 
                     <select name="country" id="country">
                     
                        <option value="saudi arabia">المملكة العربية السعودية</option>
                        <option value="Jordan">الأردن</option>
                        <option value=" United Arab Emirates UAE">الامارات العربية المتحدة</option>
                           <option value="Bahrain">البحرين</option>
                           <option value="Tunisia">تونس</option>
                           <option value="Sudan">السودان</option>
                            <option value="Syria">سوريا</option>
                            <option value="Iraq"> العراق</option>
                            <option value="Oman">عمان</option>
                            <option value="Qatar">قطر</option>
                            <option value="Kuwait"> الكويت</option>
                             <option value="Lebanon">لبنان</option>
                            <option value="Egypt">مصر</option>
                            <option value="Yemen">اليمن </option>
                            
                    
                     </select>
          
         <label>النوع</label>
          <input type="radio" name="gender" value="male" checked><label class="light" for="male">ذكر</label><br>
          <input type="radio" name="gender" value="female"><label class="light" for="female">انثى</label><br>
        <br><br>
           </fieldset>
         <h2> <span class="number">2</span>معلومات الحساب </h2>
      
        
        
        <fieldset>
        
        <img src="img\user.jpg" alt="body" class="imgbody" width=150 height=150  ><br><br><br>
          <label for="Uname">اسم المستخدم</label>
          <input type="text" id="Uname" name="Uname">
          
          
          <label for="Upassword">كلمة مرور</label>
          <input type="password" id="Upassword" name="Upassword">
          <label for="password">تأكيد كلمة المرور</label>
          <input type="password" id="password" name="password">
          
          </fieldset>
         <input type="submit" value="تسجيل" name="btn">
        <br><br><br>
        
        
         <a>لديك حساب !  <a href="singIn.php">تسجيل دخول</a></a>
     
  
    
      </form>
      <br><br>
</body>
 

<footer class="container-fluid text-center">
  <p></p>
</footer>





</html>
