<!DOCTYPE html>
<html >

<head>
  <meta charset="UTF-8">
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

  <style>
    
    button {
    background: #1A779B;
    border: none;
    padding: 5px 5px;
    color: #fff;
    border-radius: 5px;
    margin-left: 47%;
    font-size: 16px;
	    display: block;
}
  </style>
</head>


  
<body >
   <img src="img\logo.png" alt="Mountain View" class="img" width=200 height=150  >
    
    <div class="text" ><h3 style="color:#003651;">Recommended System in HealthCare </h3>
    <h4>to advise Chronic Deseases Batient</h4></div>
  
  <br><br>
    
    <form action="body.php" method="POST">
      <br><br>
      <h2> <span class="number">3</span>معلومات الجسم</h2>
        
      <fieldset>
        
        <img src="img\body.jpg" alt="body" class="imgbody" width=150 height=150  >
        <br><br><br>
          <label for="length">الطول</label>
          <input type="text" id="length" name="length">
          
          
          
          <label for="wight">الوزن</label>
          <input type="text" id="wight" name="wight">
         
          
        
      </fieldset>
  
    <h2> <span class="number">4</span>المعدلات الحيويه</h2>
        
      <fieldset>
        
        <img src="img\body.jpg" alt="body" class="imgbody" width=150 height=150  >
        <br><br><br>
          <label for="diabetes">معدل السكر بالدم</label>
          <input type="text" id="diabetes" name="diabetes" placeholder=" مثال : 81/120">
          
          <label for="pressure">معدل الضغط بالدم</label>
          <input type="text" id="pressure" name="pressure" placeholder=" مثال : 210">
          
          <label for="cholestrol">معدل الكوليسترول بالدم</label>
          <input type="text" id="cholestrol" name="cholestrol" placeholder="مثال : 200">
          
          
         <input type="submit" value="التالي" name="btn">
        <a href="singUp.php"> <input type="button" value="رجوع" name="sub" ></a>
        
      </fieldset>
    </form>
      <br><br>
</body>
 

<footer class="container-fluid text-center">
  <p></p>
</footer>





</html>
