<?php

$db = mysqli_connect("localhost","root", "", "recommended") ;
      if($db){
        print("تم الاتصال بقاعده البيانات");
        
      } else{
        print("لم يتم الاتصال بقاعده البيانات ");
      }

mysqli_set_charset($db,"utf8");

if (isset($_POST['sub'])){
  $trname=$_POST['trname'];
		$trtype=$_POST['trtype'];
    $drugs =$_POST['drugs'];
    $times =$_POST['times'];
    

  $sql="INSERT INTO treatment 
  VALUES ('NULL','$trname','$trtype', '$times' , '$drugs')";
   $result = $db->query($sql);
   
header("location:step5.php");
}

if (isset($_POST['subnext'])){
  
  
header("location:test.php");
}
?>